CREATE TABLE Khuvuc (
  KV_Ma int not null,
  KV_Ten varchar(50) NOT NULL,
  PRIMARY KEY(KV_Ma)
);

INSERT INTO Khuvuc VALUES(1,'Sanh A');
INSERT INTO Khuvuc VALUES(2,'Sanh B');
INSERT INTO Khuvuc VALUES(3,'Sanh C');
INSERT INTO Khuvuc VALUES(4,'Sanh D');

CREATE TABLE Ban (
  	B_Ma INT NOT NULL,
  	B_trangthai boolean NOT NULL,
  	B_songuoi varchar(50) NOT NULL,
  	B_Khuvuc INT NOT NULL,
  	PRIMARY KEY(B_Ma),
  	FOREIGN KEY(B_Khuvuc) REFERENCES Khuvuc(KV_Ma)
);



CREATE TABLE Nhanvien (
  	NV_Ma INT NOT NULL,
  	NV_Ten varchar(50) NOT NULL,
  	NV_Luong varchar(50),
  	NV_Congviec varchar(50),
  	NV_Ngayvaolam VARCHAR(50),
  	NV_Khuvuc INT NOT NULL,
  	PRIMARY KEY(NV_Ma),
  	FOREIGN KEY(NV_Khuvuc) REFERENCES Khuvuc(KV_Ma)
);

CREATE TABLE Loai (
  	Loai_ten VARCHAR(50) NOT NULL,
  	PRIMARY KEY(Loai_ten)
);

CREATE TABLE Thucdon (
  	TD_Ma INT NOT NULL,
  	TD_Loai varchar(50) NOT NULL,
  	TD_Tenmon varchar(50) NOT NULL,
  	TD_Gia bigInt,
  	TD_Donvitinh varchar(50),
  	TD_Hinhanh,
  	PRIMARY KEY(TD_Ma),
  	FOREIGN KEY(TD_Loai) REFERENCES Loai(loai_ten)
);
CREATE TABLE Hoadon (
  	HD_Ma INT NOT NULL,
  	HD_Trangthaithanhtoan BOOLEAN,
  	HD_Tongtien INT,
  	HD_Thoigian varchar(50),
  	PRIMARY KEY(HD_Ma)
);

CREATE TABLE Hoadonchitiet (
  	HDCT_STT INT NOT NULL,
  	B_Ma INT NOT NULL,
  	NV_Ma INT NOT NULL,
  	TD_Ma INT NOT NULL,
  	HD_Ma INT NOT NULL,
  	PRIMARY KEY(HDCT_STT,B_Ma,NV_Ma,TD_Ma),
  	FOREIGN KEY(B_Ma) REFERENCES Ban(B_Ma),
  	FOREIGN KEY(NV_Ma) REFERENCES Nhanvien(NV_Ma),
  	FOREIGN KEY(TD_Ma) REFERENCES Thucdon(TD_Ma),
  	FOREIGN KEY(HD_Ma) REFERENCES Hoadon(HD_Ma)
);

INSERT INTO Ban(B_ma,B_trangthai,B_songuoi,B_Khuvuc)
VALues(1,false,'4 nguoi',1);
INSERT INTO Ban(B_ma,B_trangthai,B_songuoi,B_Khuvuc)
VALues(2,false,'4 nguoi',2); 
INSERT INTO Ban(B_ma,B_trangthai,B_songuoi,B_Khuvuc)
VALues(3,false,'4 nguoi',3);  
INSERT INTO Ban(B_ma,B_trangthai,B_songuoi,B_Khuvuc)
VALues(4,false,'4 nguoi',4); 

INSERT INTO Nhanvien(NV_ma,NV_Ten,NV_Khuvuc)
VALUES(1,'Gia',1);
INSERT INTO Nhanvien(NV_ma,NV_Ten,NV_Khuvuc)
VALUES(2,'An',4); 
INSERT INTO Nhanvien(NV_ma,NV_Ten,NV_Khuvuc)
VALUES(3,'Trang',2); 
INSERT INTO Nhanvien(NV_ma,NV_Ten,NV_Khuvuc)
VALUES(4,'Yen',3);

INSERT INTO Loai(loai_ten) VALUES('Com');
INSERT INTO Loai(loai_ten) VALUES('Nuoc uong');

INSERT INTO Thucdon(td_ma,td_loai,td_tenmon,td_gia)
VALUES(1,'Com','Com chien duong chau','10$');
INSERT INTO Thucdon(td_ma,td_loai,td_tenmon,td_gia)
VALUES(2,'Com','Com ca moi','8$');
INSERT INTO Thucdon(td_ma,td_loai,td_tenmon,td_gia)
VALUES(3,'Nuoc uong','Coca','4$');
INSERT INTO Thucdon(td_ma,td_loai,td_tenmon,td_gia)
VALUES(4,'Nuoc uong','Pepsi','3$');

INSERT INTO Hoadon (hd_ma,hd_trangthaithanhtoan)
VALUES(1,false);
INSERT INTO Hoadon (hd_ma,hd_trangthaithanhtoan)
VALUES(2,false); 
INSERT INTO Hoadon (hd_ma,hd_trangthaithanhtoan)
VALUES(3,false); 
INSERT INTO Hoadon (hd_ma,hd_trangthaithanhtoan)
VALUES(4,false);

INSERT INTO Hoadonchitiet(HDCT_STT,B_Ma,NV_Ma,TD_Ma,HD_Ma,soluong)
VALUES(1,1,1,1,1,5);
INSERT INTO Hoadonchitiet(HDCT_STT,B_Ma,NV_Ma,TD_Ma,HD_Ma,soluong)
VALUES(2,1,1,2,1,3);
INSERT INTO Hoadonchitiet(HDCT_STT,B_Ma,NV_Ma,TD_Ma,HD_Ma,soluong)
VALUES(3,1,1,3,1,2);
INSERT INTO Hoadonchitiet(HDCT_STT,B_Ma,NV_Ma,TD_Ma,HD_Ma,soluong)
VALUES(4,2,1,1,2,4);
INSERT INTO Hoadonchitiet(HDCT_STT,B_Ma,NV_Ma,TD_Ma,HD_Ma,soluong)
VALUES(5,2,1,2,2,5);

SELECT hd.hd_ma AS Mahoadon,b.b_ma AS STTBan, nv.nv_ten AS Tennhanvien,
td.td_tenmon AS Tenmon, hdct.soluong
FROM Hoadon hd, Ban b, Nhanvien nv, Thucdon td, Hoadonchitiet as hdct
WHERE b.B_Ma = hdct.B_Ma
AND nv.nv_ma = hdct.NV_Ma
AND td.TD_Ma = hdct.td_ma
AND hd.hd_ma = hdct.hd_ma;


CREATE TABLE Khuvuc (
  KV_Ma int not null,
  KV_Ten varchar(50) NOT NULL,
  PRIMARY KEY(KV_Ma)
);

INSERT INTO Khuvuc VALUES(1,'Sanh A');
INSERT INTO Khuvuc VALUES(2,'Sanh B');
INSERT INTO Khuvuc VALUES(3,'Sanh C');
INSERT INTO Khuvuc VALUES(4,'Sanh D');

CREATE TABLE Ban (
  	B_Ma INT NOT NULL,
  	B_trangthai boolean NOT NULL,
  	B_songuoi varchar(50) NOT NULL,
  	B_Khuvuc INT NOT NULL,
  	PRIMARY KEY(B_Ma),
  	FOREIGN KEY(B_Khuvuc) REFERENCES Khuvuc(KV_Ma)
);



CREATE TABLE Nhanvien (
  	NV_Ma INT NOT NULL,
  	NV_Ten varchar(50) NOT NULL,
  	NV_Luong varchar(50),
  	NV_Congviec varchar(50),
  	NV_Ngayvaolam VARCHAR(50),
  	NV_Khuvuc INT NOT NULL,
  	PRIMARY KEY(NV_Ma),
  	FOREIGN KEY(NV_Khuvuc) REFERENCES Khuvuc(KV_Ma)
);

CREATE TABLE Loai (
  	Loai_ten VARCHAR(50) NOT NULL,
  	PRIMARY KEY(Loai_ten)
);

CREATE TABLE Thucdon (
  	TD_Ma INT NOT NULL,
  	TD_Loai varchar(50) NOT NULL,
  	TD_Tenmon varchar(50) NOT NULL,
  	TD_Gia bigInt,
  	TD_Donvitinh varchar(50),
  	TD_Hinhanh,
  	PRIMARY KEY(TD_Ma),
  	FOREIGN KEY(TD_Loai) REFERENCES Loai(loai_ten)
);
CREATE TABLE Hoadon (
  	HD_Ma INT NOT NULL,
  	HD_Trangthaithanhtoan BOOLEAN,
  	HD_Tongtien INT,
  	HD_Thoigian varchar(50),
  	PRIMARY KEY(HD_Ma)
);

CREATE TABLE Hoadonchitiet (
  	HDCT_STT INT NOT NULL,
  	B_Ma INT NOT NULL,
  	NV_Ma INT NOT NULL,
  	TD_Ma INT NOT NULL,
  	HD_Ma INT NOT NULL,
  	PRIMARY KEY(HDCT_STT,B_Ma,NV_Ma,TD_Ma),
  	FOREIGN KEY(B_Ma) REFERENCES Ban(B_Ma),
  	FOREIGN KEY(NV_Ma) REFERENCES Nhanvien(NV_Ma),
  	FOREIGN KEY(TD_Ma) REFERENCES Thucdon(TD_Ma),
  	FOREIGN KEY(HD_Ma) REFERENCES Hoadon(HD_Ma)
);

INSERT INTO Ban(B_ma,B_trangthai,B_songuoi,B_Khuvuc)
VALues(1,false,'4 nguoi',1);
INSERT INTO Ban(B_ma,B_trangthai,B_songuoi,B_Khuvuc)
VALues(2,false,'4 nguoi',2); 
INSERT INTO Ban(B_ma,B_trangthai,B_songuoi,B_Khuvuc)
VALues(3,false,'4 nguoi',3);  
INSERT INTO Ban(B_ma,B_trangthai,B_songuoi,B_Khuvuc)
VALues(4,false,'4 nguoi',4); 

INSERT INTO Nhanvien(NV_ma,NV_Ten,NV_Khuvuc)
VALUES(1,'Gia',1);
INSERT INTO Nhanvien(NV_ma,NV_Ten,NV_Khuvuc)
VALUES(2,'An',4); 
INSERT INTO Nhanvien(NV_ma,NV_Ten,NV_Khuvuc)
VALUES(3,'Trang',2); 
INSERT INTO Nhanvien(NV_ma,NV_Ten,NV_Khuvuc)
VALUES(4,'Yen',3);

INSERT INTO Loai(loai_ten) VALUES('Com');
INSERT INTO Loai(loai_ten) VALUES('Nuoc uong');

INSERT INTO Thucdon(td_ma,td_loai,td_tenmon,td_gia)
VALUES(1,'Com','Com chien duong chau','10$');
INSERT INTO Thucdon(td_ma,td_loai,td_tenmon,td_gia)
VALUES(2,'Com','Com ca moi','8$');
INSERT INTO Thucdon(td_ma,td_loai,td_tenmon,td_gia)
VALUES(3,'Nuoc uong','Coca','4$');
INSERT INTO Thucdon(td_ma,td_loai,td_tenmon,td_gia)
VALUES(4,'Nuoc uong','Pepsi','3$');

INSERT INTO Hoadon (hd_ma,hd_trangthaithanhtoan)
VALUES(1,false);
INSERT INTO Hoadon (hd_ma,hd_trangthaithanhtoan)
VALUES(2,false); 
INSERT INTO Hoadon (hd_ma,hd_trangthaithanhtoan)
VALUES(3,false); 
INSERT INTO Hoadon (hd_ma,hd_trangthaithanhtoan)
VALUES(4,false);

INSERT INTO Hoadonchitiet(HDCT_STT,B_Ma,NV_Ma,TD_Ma,HD_Ma,soluong)
VALUES(1,1,1,1,1,5);
INSERT INTO Hoadonchitiet(HDCT_STT,B_Ma,NV_Ma,TD_Ma,HD_Ma,soluong)
VALUES(2,1,1,2,1,3);
INSERT INTO Hoadonchitiet(HDCT_STT,B_Ma,NV_Ma,TD_Ma,HD_Ma,soluong)
VALUES(3,1,1,3,1,2);
INSERT INTO Hoadonchitiet(HDCT_STT,B_Ma,NV_Ma,TD_Ma,HD_Ma,soluong)
VALUES(4,2,1,1,2,4);
INSERT INTO Hoadonchitiet(HDCT_STT,B_Ma,NV_Ma,TD_Ma,HD_Ma,soluong)
VALUES(5,2,1,2,2,5);

SELECT hd.hd_ma AS Mahoadon,b.b_ma AS STTBan, nv.nv_ten AS Tennhanvien,
td.td_tenmon AS Tenmon, hdct.soluong
FROM Hoadon hd, Ban b, Nhanvien nv, Thucdon td, Hoadonchitiet as hdct
WHERE b.B_Ma = hdct.B_Ma
AND nv.nv_ma = hdct.NV_Ma
AND td.TD_Ma = hdct.td_ma
AND hd.hd_ma = hdct.hd_ma;


